//
//  InscriptionViewController.m
//  lucky_CV_1_0
//
//  Created by if26 on 12/12/13.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//

#import "InscriptionViewController.h"

@interface InscriptionViewController ()

@end

@implementation InscriptionViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


// Ce qui se passe quand on clique sur le bouton S'inscrire
- (IBAction)click_inscrire:(id)sender {

    [self verifierInscription];
       
}

// Permet de cacher le menu lorsqu'on clique sur le bouton retour quand le clavier est visible
- (BOOL)verifierInscription{
    NSString *nom = _nom.text;
    NSString *prenom = _prenom.text;
    NSString *email = _email.text;
    NSString *login = _login.text;
    NSString *password = _password.text;
    NSString *passwordConfirme = _passwordConfirme.text;
    BOOL *inscriptionPossible = false;
    
    
    // Tous les champs sont obligatoires.
    // On vérifie que l'utilisateur a rentré au moins un caractère dans chaque champs
    if ( [nom length] < 1 || [prenom length] < 1 || [email length] < 1 || [login length] < 1 || [password length] < 1 || [passwordConfirme length] < 1 )
    {
        UIAlertView *someError = [[UIAlertView alloc] initWithTitle: @"Champs obligatoires" message: @"Vous n'avez pas rempli tous les champs" delegate: self cancelButtonTitle: @"Ok" otherButtonTitles: nil];
        
        [someError show];
    } else {
        
        // On vérifie que les deux mots de passe sont identiques
        if (![password isEqualToString:passwordConfirme]){
            // Les password sont différents, on affiche un message d'erreur à l'utilisateur
            UIAlertView *someError = [[UIAlertView alloc] initWithTitle: @"Mots de passe" message: @"Vous deux mots de passe sont différents" delegate: self cancelButtonTitle: @"OK" otherButtonTitles: nil];
            [someError show];
        } else {
            // Les mots de passe sont identiques, on vérifie leur complexité
            NSString *passwordRegEx = @"[A-Za-z0-9]{8,50}";
            NSPredicate *passwordTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", passwordRegEx];
            // le mot de passe n'est pas suffisamment complexe
            if ([passwordTest evaluateWithObject:password] == NO) {
                // on affiche un message d'erreur à l'utilisateur
                UIAlertView *someError = [[UIAlertView alloc] initWithTitle: @"Mots de passe" message: @"Votre mot de passe n'est pas suffisamment compliqué, 8 caractères minimum" delegate: self cancelButtonTitle: @"OK" otherButtonTitles: nil];
                [someError show];
            } else {
                inscriptionPossible = true;
                
            }
            
            // tous les champs ont été remplis, on vérifie l'adresse email
            NSString *emailRegEx = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9-]+\\.[A-Za-z]{2,4}";
            NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegEx];
            // On vérifie l'adresse email
            if ([emailTest evaluateWithObject:email] == NO)
            {
                inscriptionPossible = false;
                // Adresse email invalide, on affiche un message d'erreur
                UIAlertView *someError = [[UIAlertView alloc] initWithTitle: @"Adresse mail invalide" message: @"Votre adresse email n'est pas valide" delegate: self cancelButtonTitle: @"OK" otherButtonTitles: nil];
                [someError show];
                
            }
            
        }
        
    }
    
   // return inscriptionPossible;
}



// Permet de cacher le menu lorsqu'on clique sur le bouton retour quand le clavier est visible
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}





@end
