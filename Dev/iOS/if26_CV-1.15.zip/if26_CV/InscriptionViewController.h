//
//  InscriptionViewController.h
//  lucky_CV_1_0
//
//  Created by if26 on 12/12/13.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InscriptionViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *nom;
@property (weak, nonatomic) IBOutlet UITextField *prenom;
@property (weak, nonatomic) IBOutlet UITextField *email;
@property (weak, nonatomic) IBOutlet UITextField *login;
@property (weak, nonatomic) IBOutlet UITextField *password;
@property (weak, nonatomic) IBOutlet UITextField *passwordConfirme;
- (BOOL)verifierInscription;
@end
