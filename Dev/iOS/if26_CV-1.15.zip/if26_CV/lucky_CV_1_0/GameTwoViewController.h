//
//  GameTwoViewController.h
//  lucky_CV_1_0
//
//  Created by if26 on 04/12/13.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GameTwoViewController : UIViewController

@end
