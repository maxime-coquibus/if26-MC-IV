//
//  AppDelegate.m
//  lucky_CV_1_0
//
//  Created by if26 on 03/12/13.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//

#import "AppDelegate.h"
#import "ConnectionViewController.h"
#import "ListGameViewController.h"
#import "HistoViewController.h"
#import "AproposViewController.h"
#import "DeconnectionViewController.h"
#import "GameOneViewController.h"
#import "InscriptionViewController.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{

    // GESTION TAB BAR + avec NAVIGATINCONTROLLER POUR POUVOIR REVENIR A LA PAGE D'AVANT
    // Création de la fenêtre
    self.window = [[UIWindow alloc ]
                   initWithFrame:[[UIScreen mainScreen]bounds]];

    // création tabBar
    UITabBarController *tabBar = [[UITabBarController alloc] init];
    
    // Création de l'onglet connexion et inscription (page d'accueil)
    ConnectionViewController *connection = [[ConnectionViewController alloc]init];
    _connectionViewController = [[UINavigationController alloc] initWithRootViewController:connection];
    _connectionViewController.tabBarItem.title = @"Connexion";
    _connectionViewController.tabBarItem.titlePositionAdjustment = UIOffsetMake(0, -15.0);
    InscriptionViewController *inscription = [[InscriptionViewController alloc]init];
    _inscriptionViewController = [[UINavigationController alloc] initWithRootViewController:inscription];
    _inscriptionViewController.tabBarItem.title = @"Inscription";
    _inscriptionViewController.tabBarItem.titlePositionAdjustment = UIOffsetMake(0, -15.0);
    
    // Ajout des onglets
    NSArray *viewControllersArray = [NSArray arrayWithObjects:_connectionViewController, _inscriptionViewController, nil];
    [tabBar setViewControllers:viewControllersArray animated:NO];
    
    self.window.rootViewController = tabBar;
    
    // On instancie ConnectionViewController
    [self.window makeKeyAndVisible];
    
    /*
    presentViewController affichage fenêtre de connexion ; DismissViewController enlever fenêtre de connexion
    UITabBar -> gérer si connecté ou nom
    ViewWillAppear
    */
    return YES;
}

// Charge les onglets une fois la connexion réussie
- (void) loadTabApp
{
    // Affichage d'une fenêtre de bienvenue
    UIAlertView * alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Welcome - Bienvenue",@"")message:NSLocalizedString(@"Bienvenue sur Lucky ! Amusez-vous.", @"") delegate:nil cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil];
    [alert show];
    
    // création tabBar
    UITabBarController *tabBar = [[UITabBarController alloc] init];
    // Création des différents onglets avec NAVIGATINCONTROLLER POUR POUVOIR REVENIR A LA PAGE D'AVANT
    AproposViewController *apropos = [[AproposViewController alloc]init];
    _aproposNavController = [[UINavigationController alloc] initWithRootViewController:apropos];
    _aproposNavController.tabBarItem.title = @"A propos";
    _aproposNavController.tabBarItem.titlePositionAdjustment = UIOffsetMake(0, -15.0);
    
    HistoViewController *histo = [[HistoViewController alloc]init];
    _histoNavController = [[UINavigationController alloc] initWithRootViewController:histo];
    _histoNavController.tabBarItem.title = @"Historique";
    _histoNavController.tabBarItem.titlePositionAdjustment = UIOffsetMake(0, -15.0);
    
    ListGameViewController *listGame = [[ListGameViewController alloc]init];
    _listgameNavController = [[UINavigationController alloc] initWithRootViewController:listGame];
    _listgameNavController.tabBarItem.title = @"Liste jeux";
    _listgameNavController.tabBarItem.titlePositionAdjustment = UIOffsetMake(0, -15.0);
    
    DeconnectionViewController *deconnection = [[DeconnectionViewController alloc]init];
    _decoNavController = [[UINavigationController alloc] initWithRootViewController:deconnection];
    _decoNavController.tabBarItem.title = @"Déconnexion";
    _decoNavController.tabBarItem.titlePositionAdjustment = UIOffsetMake(0, -15.0);
    // Ajout à la vue
    NSArray *viewControllersArray = [NSArray arrayWithObjects:_listgameNavController, _histoNavController, _aproposNavController, _decoNavController, nil];
    [tabBar setViewControllers:viewControllersArray animated:NO];
    
    self.window.rootViewController = tabBar;
    
    // On instancie ConnectionViewController
    [self.window makeKeyAndVisible];
    
}
- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
