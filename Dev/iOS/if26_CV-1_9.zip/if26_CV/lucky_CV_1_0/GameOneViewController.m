//
//  GameOneViewController.m
//  lucky_CV_1_0
//
//  Created by if26 on 04/12/13.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//

#define url_WebServQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)
#define url_WebServ [NSURL URLWithString:@"http://localhost:8888/projet_if26/"]
#define urlString @"http://localhost:8888/projet_if26/"

#import "GameOneViewController.h"

@interface GameOneViewController ()

@end


// POUR JSON
@interface NSDictionary(JSONCategories)
+(NSArray*)valueFromJSON:
(NSDictionary*) dico withArg2:(NSString*)chaineRecherche;
+(NSDictionary*)dictionaryWithContentsOfJSONURLString:
(NSString*)urlAddress;
-(NSData*)toJSON;

@end

@implementation NSDictionary(JSONCategories)

// Retourne la valeur du Json en lui passant tout le dictionnaire du Json et la chaine recherchée. Return telle valeur.
+(NSArray*)valueFromJSON:
(NSDictionary*)dico
withArg2:(NSString*)chaineRecherche;
{
    NSArray* getJson = [dico objectForKey:[NSString stringWithFormat:@"%@",chaineRecherche]];
    return getJson;
}

// Télécharge dictionnaire de données en fonction de l'url passée en paramètre
+(NSDictionary*)dictionaryWithContentsOfJSONURLString:
(NSString*)urlAddress
{
    NSData* data = [NSData dataWithContentsOfURL:[NSURL URLWithString: urlAddress] ];
    __autoreleasing NSError* error = nil;
    id result = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
    
    if (error != nil)
        return nil;
    return result;
}


-(NSData*)toJSON
{
    NSError* error = nil;
    id result = [NSJSONSerialization dataWithJSONObject:self options:kNilOptions error:&error];
    if (error != nil)
        return nil;
    return result;
}

@end


@implementation GameOneViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Dictionnaire de données. Les télécharge à l'url indiquée dans le define au dessus
    NSDictionary* myInfo =[NSDictionary dictionaryWithContentsOfJSONURLString:urlString];
    // On met les infos dans le label
    _recupJson.text = [NSString stringWithFormat:@"Récupération du Json: %@", [NSDictionary valueFromJSON:myInfo withArg2:@"lol"]];
}

// Inutilisé pour le moment
- (void)fetchedData:(NSData *)responseData {
    
    // MARCHE
  //  NSDictionary* myInfo =[NSDictionary dictionaryWithContentsOfJSONURLString:@"http://localhost:8888/projet_if26/"];
    // NSDictionary* information = [NSDictionary dictionaryWithObjectsAndKeys:@"toto",@"lama",nil];
    // NSArray* getJson = [NSDictionary valueFromJSON:myInfo];
    
    
    // On met les infos dans le label
  //  _recupJson.text = [NSString stringWithFormat:@"Récupération du Json: %@", [NSDictionary valueFromJSON:myInfo]];
    
    
/*
    NSDictionary* json = [NSJSONSerialization
                          JSONObjectWithData:responseData
                          
                          options:NSJSONReadingAllowFragments
                          error:&error];
    // Obtenir le json (champ à modifier en fonction de ce qu'on veut obtenir)
    NSArray* getJson = [json objectForKey:@"lol"];
*/
    
    /*
    // 1) Get the latest loan
    NSDictionary* loan = [latestLoans objectAtIndex:0];
    // 2) Get the funded amount and loan amount
    NSNumber* fundedAmount = [loan objectForKey:@"lama"];
    NSNumber* loanAmount = [loan objectForKey:@"lamas"];
    float outstandingAmount = [loanAmount floatValue] -
    [fundedAmount floatValue];
    // 3) On met les infos dans le label
    _recupJson.text = [NSString stringWithFormat:@"Latest loan: %@ from %@ needs another $%.2f toto", [loan objectForKey:@"lama"],[(NSDictionary*)[loan objectForKey:@"lamas"] objectForKey:@"lama"],outstandingAmount];
    */
    
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end



