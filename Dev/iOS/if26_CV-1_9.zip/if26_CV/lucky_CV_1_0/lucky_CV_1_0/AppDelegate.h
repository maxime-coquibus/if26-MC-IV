//
//  AppDelegate.h
//  lucky_CV_1_0
//
//  Created by if26 on 03/12/13.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ListGameViewController.h"


@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, strong) UINavigationController *navigationController;
@property (nonatomic, retain) UINavigationController *aproposNavController;
@property (nonatomic, retain) UINavigationController *histoNavController;
@property (nonatomic, retain) UINavigationController *decoNavController;
@property (nonatomic, retain) UINavigationController *listgameNavController;
@property (nonatomic, retain) IBOutlet ListGameViewController *listGameViewController;
@end