//
//  ConnectionViewController.m
//  lucky_CV_1_0
//
//  Created by if26 on 03/12/13.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//

#import "ConnectionViewController.h"
#import "ListGameViewController.h"

@interface ConnectionViewController ()

@end


@implementation ConnectionViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}



- (IBAction)click_login:(id)sender {
    
    NSString *recupLogin = _login.text;
    NSString *recupPassword = _password.text;
    
    ListGameViewController *listGameViewController = [[ListGameViewController alloc] initWithNibName:nil
                                                                                                bundle:NULL];
    [self.navigationController pushViewController:listGameViewController animated:YES];
    
 
    
    
    // ALERTE DE TEST A SUPPRIMER
    /*
    UIAlertView * alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@" Alerte",@"")message:NSLocalizedString(recupLogin, @"") delegate:nil cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil];
    [alert show];
    */
    
    
}
@end
