//
//  InscriptionViewController.m
//  lucky_CV_1_0
//
//  Created by if26 on 12/12/13.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//

#import "InscriptionViewController.h"
#import "SBJson.h"

@interface InscriptionViewController ()

@end

@implementation InscriptionViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


// Ce qui se passe quand on clique sur le bouton S'inscrire
- (IBAction)click_inscrire:(id)sender {
    BOOL inscriptionPossible = NO;
    // On vérifie si l'inscription est possible en appelant notre procédure
    inscriptionPossible = [self verifierInscription];
    
    if(inscriptionPossible){
       // TOUT est valide, on peut inscrire l'utilisateur
        
        // On récupère le texte des champs login et password
        NSString *nom = _nom.text;
        NSString *prenom = _prenom.text;
        NSString *email = _email.text;
        NSString *login = _login.text;
        NSString *password = _password.text;
        NSString *passwordConfirme = _passwordConfirme.text;
        
        
        // ENVOI DES DONNEES (A MODIFIER EN UTILISANT WEBSERVICE)        
                        NSString *post =[[NSString alloc] initWithFormat:@"data[User][username]=%@&data[User][password]=%@",nom,prenom];
                
                // Url fichier php login
                NSURL *url=[NSURL URLWithString:@"http://localhost/lucky/api/json/inscription"];
                
                NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
                NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
                
                // On définit notre requête
                NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
                // Différents éléments de la requête. Passage en post
                [request setURL:url];
                [request setHTTPMethod:@"POST"];
                [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
                [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
                [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
                [request setHTTPBody:postData];
                
                //[NSURLRequest setAllowsAnyHTTPSCertificate:YES forHost:[url host]];
                
                NSError *error = [[NSError alloc] init];
                NSHTTPURLResponse *response = nil;
                NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
                
                // Contrôle du login et du mot de passe
                if ([response statusCode] >=200 && [response statusCode] <300)
                {
                    NSString *responseData = [[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
                    // Parsage json
                    SBJsonParser *jsonParser = [SBJsonParser new];
                    NSDictionary *jsonData = (NSDictionary *) [jsonParser objectWithString:responseData error:nil];
                    NSInteger success = [(NSNumber *) [jsonData objectForKey:@"success"] integerValue];
                    NSString* token = [jsonData objectForKey:@"token"];
                    // Si bon mot de passe et login
                    if(success == 1)
                    {
                        // FONCTIONNEMENT OK
                        
                    }
                }
    }
}


/*
Vérifie si l'inscription est possible et affiche les messages d'erreurs en conséquence : aucun champ vide, adresse email valide, mot de passe suffisamment compliqué et deux mots de passe saisies identiques.
 
 Returne YES si l'inscription est possible, NO sinon.
 */

- (BOOL)verifierInscription{
    BOOL inscriptionPossible = NO;
    NSString *nom = _nom.text;
    NSString *prenom = _prenom.text;
    NSString *email = _email.text;
    NSString *login = _login.text;
    NSString *password = _password.text;
    NSString *passwordConfirme = _passwordConfirme.text;
    
    
    // Tous les champs sont obligatoires.
    // On vérifie que l'utilisateur a rentré au moins un caractère dans chaque champs
    if ( [nom length] < 1 || [prenom length] < 1 || [email length] < 1 || [login length] < 1 || [password length] < 1 || [passwordConfirme length] < 1 )
    {
        UIAlertView *someError = [[UIAlertView alloc] initWithTitle: @"Champs obligatoires" message: @"Vous n'avez pas rempli tous les champs" delegate: self cancelButtonTitle: @"Ok" otherButtonTitles: nil];
        [someError show];
        
    } else {
        // On vérifie que les deux mots de passe sont identiques
        if (![password isEqualToString:passwordConfirme]){
            // Les password sont différents, on affiche un message d'erreur à l'utilisateur
            UIAlertView *someError = [[UIAlertView alloc] initWithTitle: @"Mots de passe" message: @"Vos deux mots de passe sont différents" delegate: self cancelButtonTitle: @"OK" otherButtonTitles: nil];
            [someError show];
            
        } else {
            // Les mots de passe sont identiques, on vérifie leur complexité
            // 8 caractères minimum
            NSString *passwordRegEx = @"[A-Za-z0-9]{8,50}";
            NSPredicate *passwordTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", passwordRegEx];
            // le mot de passe n'est pas suffisamment complexe
            if ([passwordTest evaluateWithObject:password] == NO) {
                // on affiche un message d'erreur à l'utilisateur
                UIAlertView *someError = [[UIAlertView alloc] initWithTitle: @"Mots de passe" message: @"Votre mot de passe n'est pas suffisamment compliqué, 8 caractères minimum" delegate: self cancelButtonTitle: @"OK" otherButtonTitles: nil];
                [someError show];
            } else { // Sinon l'inscription est possible
                inscriptionPossible = YES;
            }
            
            // tous les champs ont été remplis, on vérifie l'adresse email
            NSString *emailRegEx = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9-]+\\.[A-Za-z]{2,4}";
            NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegEx];
            // On vérifie l'adresse email
            if ([emailTest evaluateWithObject:email] == NO)
            {
                inscriptionPossible = NO;
                // Adresse email invalide, on affiche un message d'erreur
                UIAlertView *someError = [[UIAlertView alloc] initWithTitle: @"Adresse mail invalide" message: @"Votre adresse email n'est pas valide" delegate: self cancelButtonTitle: @"OK" otherButtonTitles: nil];
                [someError show];
            }
        }
    }
    // Retourne si l'inscription est possible ou non.
    return inscriptionPossible;
}

// Permet de cacher le menu lorsqu'on clique sur le bouton retour quand le clavier est visible
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}


@end
