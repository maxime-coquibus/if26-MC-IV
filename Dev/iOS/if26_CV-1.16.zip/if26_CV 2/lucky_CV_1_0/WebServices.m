//
//  WebServices.m
//  lucky_CV_1_0
//
//  Created by Igor VINCENT on 17/12/2013.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//

#import "WebServices.h"
#import "SBJson.h"

@implementation WebServices


/*
    A modifier / compléter 
    urlJSON : exemple de string à passer : inscription 
 
*/
-(void) sendRequest:(NSString*) urlJSON withArg2:(NSString*)dataOne withArg3:(NSString*) dataTwo
{
    
    NSString *post =[[NSString alloc] initWithFormat:@"data[User][username]=%@&data[User][password]=%@",dataOne,dataTwo];
    
    // url json
    NSString *urlstring = [NSString stringWithFormat:@"%@/%@",url_WebServ, urlJSON];
    NSURL *url=[NSURL URLWithString:urlstring];
    
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
    
    // On définit notre requête
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    
    // Différents éléments de la requête. Passage en post
    [request setURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:postData];
    
    //[NSURLRequest setAllowsAnyHTTPSCertificate:YES forHost:[url host]];
    
    NSError *error = [[NSError alloc] init];
    NSHTTPURLResponse *response = nil;
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    // Contrôle du login et du mot de passe
    if ([response statusCode] >=200 && [response statusCode] <300)
    {
        NSString *responseData = [[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
        // Parsage json
        SBJsonParser *jsonParser = [SBJsonParser new];
        NSDictionary *jsonData = (NSDictionary *) [jsonParser objectWithString:responseData error:nil];
        NSInteger success = [(NSNumber *) [jsonData objectForKey:@"success"] integerValue];
        NSString* token = [jsonData objectForKey:@"token"];
        // Si bon mot de passe et login
        if(success == 1)
        {
            // FONCTIONNEMENT OK
            
        }
    }
    
    
    
}

@end
