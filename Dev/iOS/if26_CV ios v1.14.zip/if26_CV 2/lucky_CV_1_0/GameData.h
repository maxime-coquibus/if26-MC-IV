//
//  GameData.h
//  lucky_CV_1_0
//
//  Created by Igor VINCENT on 02/01/2014.
//  Copyright (c) 2014 utt_CV. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GameData : NSObject
//attribut des données de jeux
@property (strong,nonatomic) NSString* nomJeu;
@property (strong,nonatomic) NSString* style;
@property (strong,nonatomic) NSString* nbGagnant;
@property (strong,nonatomic) NSString* identificateur;
@property (strong,nonatomic) NSString* probaVictoire;
//constructeur
-(GameData *) initWithName:(NSString *)nom_ style:(NSString*)style_ nbGagnant:(NSString*)nbGagnant_ identificateur:(NSString*)identificateur_ probaVictoire:(NSString*)probaVictoire_;

//getter
-(NSString *) getNom;
-(NSString *) getProbVictoire;
-(NSString *) getId;
-(NSString *) getStyle;
@end
