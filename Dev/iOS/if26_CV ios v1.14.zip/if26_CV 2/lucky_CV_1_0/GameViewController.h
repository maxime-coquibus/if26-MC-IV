//
//  GameViewController.h
//  lucky_CV_1_0
//
//  Created by Igor VINCENT on 02/01/2014.
//  Copyright (c) 2014 utt_CV. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GameData.h"
#import "User.h"
#import "WebServices.h"

@interface GameViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *nomJeu;
//property gameData + getter & setter
@property (nonatomic,strong) GameData* gameData;
@property (nonatomic,strong) User* user;
- (IBAction)jouer:(id)sender;

@end
