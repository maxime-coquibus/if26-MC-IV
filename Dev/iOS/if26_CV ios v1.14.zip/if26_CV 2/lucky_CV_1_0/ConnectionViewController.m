//
//  ConnectionViewController.m
//  lucky_CV_1_0
//
//  Created by if26 on 03/12/13.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//

#import "ConnectionViewController.h"
#import "ListGameViewController.h"
#import "SBJson.h"
#import "AppDelegate.h"
#import "User.h"
@interface ConnectionViewController ()

@end


@implementation ConnectionViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// Permet de cacher le menu lorsqu'on clique sur le bouton retour quand le clavier est visible
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}


// Envoi les messages d'alerte (Connexion a échoué ou connexion réussie par exemple)
- (void) alertStatus:(NSString *)msg :(NSString *)title
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:msg
                                                       delegate:self
                                              cancelButtonTitle:@"Ok"
                                              otherButtonTitles:nil, nil];
    
    [alertView show];
}

- (IBAction)click_login:(id)sender {
    // On récupère le texte des champs login et password
    NSString *recupLogin = _login.text;
    NSString *recupPassword = _password.text;
    
    // Vérification du login et password en utilisant le framework json iOS
    @try {
        // Si les champs sont vides
        if([recupLogin isEqualToString:@""] || [recupPassword isEqualToString:@""] ) {
            [self alertStatus:@"Merci d'entrer votre login et votre mot de passe" :@"La connexion a échoué"];
        } else // Sinon on fait les tests suivants
        {
            NSString *post =[[NSString alloc] initWithFormat:@"data[User][username]=%@&data[User][password]=%@",recupLogin,recupPassword];
            
            // Url fichier php login
            NSURL *url=[NSURL URLWithString:@"http://localhost/lucky/api/json/login"];
            
            NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
            NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
           
            // On définit notre requête
            NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
            // Différents éléments de la requête. Passage en post
            [request setURL:url];
            [request setHTTPMethod:@"POST"];
            [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
            [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
            [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
            [request setHTTPBody:postData];
            
            //[NSURLRequest setAllowsAnyHTTPSCertificate:YES forHost:[url host]];
            
            NSError *error = [[NSError alloc] init];
            NSHTTPURLResponse *response = nil;
            NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
            
            // Contrôle du login et du mot de passe
            if ([response statusCode] >=200 && [response statusCode] <300)
            {
                NSString *responseData = [[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
                // Parsage json
                SBJsonParser *jsonParser = [SBJsonParser new];
                NSDictionary *jsonData = (NSDictionary *) [jsonParser objectWithString:responseData error:nil];
                NSInteger success = [(NSNumber *) [jsonData objectForKey:@"success"] integerValue];
                NSString* token = [jsonData objectForKey:@"token"];

                // Si bon mot de passe et login
                if(success == 1)
                {
                    
                    // L'UTILISATEUR EST LOGGUE ICI
                    User *user = [[User alloc] init];
                    [user test:token];
                    // On cache la fenêtre de connexion
                    [self dismissViewControllerAnimated:NO completion:nil];
                    // On affiche l'application et les onglets
                    [((AppDelegate*) [[UIApplication sharedApplication] delegate]) loadTabApp:user];
                    
                } else { // Sinon erreur
                    NSString *error_msg = (NSString *) [jsonData objectForKey:@"error_message"];
                    [self alertStatus:error_msg :@"Mauvais login success."];
                }
                
            } else { // Sinon erreur
                if (error)
                [self alertStatus:@"La connexion a échoué" :@"Mauvais login response code."];
            }
        }
    }
    @catch (NSException * e) { // Gestion exception
        NSLog(@"Exception: %@", e);
        [self alertStatus:@"Mauvais login." :@"Mauvais login."];
    }
}
@end
