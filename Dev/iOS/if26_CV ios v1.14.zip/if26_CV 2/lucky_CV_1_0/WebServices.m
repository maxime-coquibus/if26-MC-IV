//
//  WebServices.m
//  lucky_CV_1_0
//
//  Created by Igor VINCENT on 17/12/2013.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//

#import "WebServices.h"
#import "SBJson.h"

@interface WebServices()

@end

@implementation WebServices


/*
    méthode permettant d'envoyer une requete http
    prend l'url et un tableau contenant les paramètre en requete
    renvoie une nsstring contenant le json de réponse
 
 */
-(NSString*) requeteHttp : (NSString*) urlJSON parametre:(NSArray*) params
{
    //creation d'une chaine pour contenir les parametre
    NSString *values = [[NSString alloc] initWithFormat:@""];
    //recuperation des paramtre dans le tableau, chaque valeur doit avoir le format champ=val
    values = [params componentsJoinedByString:@"&"];
    //creation de l'adresse l'url de la requete à partir de la constante
    NSString *urlstring = [NSString stringWithFormat:@"%@/%@",url_WebServ, urlJSON];
    //creation de l'url
    NSURL *url=[NSURL URLWithString:urlstring];
    //mise en forme des données à envoyer
    NSData *postData = [values dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    //récuperation de la taille des données
    NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
    //creation de la requette
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    //set des variables de la requete
    [request setURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:postData];
    //creation d'une erreur
    NSError *error = [[NSError alloc] init];
    //creation de la reponse
    NSHTTPURLResponse *response = nil;
    //envoie de la requete
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    // Contrôle du statut de reponse
    if ([response statusCode] >=200 && [response statusCode] <300)
    {
        //recuperation des valeurs
        NSString *responseData = [[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
        return responseData;
       
    }else{
        //ici traitement de réponse
        return @"erreur response";
    }
    
    
}


@end
