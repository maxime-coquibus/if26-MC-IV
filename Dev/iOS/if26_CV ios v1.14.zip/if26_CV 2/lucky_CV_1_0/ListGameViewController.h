//
//  ListGameViewController.h
//  lucky_CV_1_0
//
//  Created by if26 on 03/12/13.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "User.h"

@interface ListGameViewController : UITableViewController
@property (nonatomic,strong) NSMutableArray *games;
@property (nonatomic,strong) NSMutableArray *gamesData;
@property (nonatomic,strong) User* user;
-(void) setUser:(User *)user_in;
-(User *) getUser;

@end
