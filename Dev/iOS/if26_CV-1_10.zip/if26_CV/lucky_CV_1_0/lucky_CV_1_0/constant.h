//
//  constant.h
//  lucky_CV_1_0
//
//  Created by if26 on 10/12/13.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//

#ifndef lucky_CV_1_0_constant_h
#define lucky_CV_1_0_constant_h

#define url_WebServQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)
#define url_WebServ [NSURL URLWithString:@"http://localhost:8888/projet_if26/"]
#define urlString @"http://localhost:8888/projet_if26/"

#endif
