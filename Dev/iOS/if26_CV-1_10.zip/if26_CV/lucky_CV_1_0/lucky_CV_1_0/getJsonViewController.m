//
//  getJsonViewController.m
//  lucky_CV_1_0
//
//  Created by if26 on 10/12/13.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//
#import "getJsonViewController.h"


@interface getJsonViewController ()

@end

@implementation getJsonViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

// POUR JSON
@interface NSDictionary(JSONCategories)
+(NSArray*)valueFromJSON:
(NSDictionary*) dico withArg2:(NSString*)chaineRecherche;
+(NSDictionary*)dictionaryWithContentsOfJSONURLString:
(NSString*)urlAddress;
-(NSData*)toJSON;

@end

@implementation NSDictionary(JSONCategories)

// Retourne la valeur du Json en lui passant tout le dictionnaire du Json et la chaine recherchée. Return telle valeur.
+(NSArray*)valueFromJSON:
(NSDictionary*)dico
                withArg2:(NSString*)chaineRecherche;
{
    NSArray* getJson = [dico objectForKey:[NSString stringWithFormat:@"%@",chaineRecherche]];
    return getJson;
}

// Télécharge dictionnaire de données en fonction de l'url passée en paramètre
+(NSDictionary*)dictionaryWithContentsOfJSONURLString:
(NSString*)urlAddress
{
    NSData* data = [NSData dataWithContentsOfURL:[NSURL URLWithString: urlAddress] ];
    __autoreleasing NSError* error = nil;
    id result = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
    
    if (error != nil)
        return nil;
    return result;
}


-(NSData*)toJSON
{
    NSError* error = nil;
    id result = [NSJSONSerialization dataWithJSONObject:self options:kNilOptions error:&error];
    if (error != nil)
        return nil;
    return result;
}

@end