//
//  ConnectionViewController.h
//  lucky_CV_1_0
//
//  Created by if26 on 03/12/13.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConnectionViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *login;
@property (weak, nonatomic) IBOutlet UITextField *password;
- (IBAction)click_login:(id)sender;

@end
