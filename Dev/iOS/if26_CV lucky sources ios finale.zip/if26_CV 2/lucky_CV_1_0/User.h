//
//  User.h
//  lucky_CV_1_0
//
//  Created by Igor VINCENT on 17/12/2013.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface User : NSObject
@property (strong,nonatomic) NSString* username;
@property (strong, nonatomic) NSString* token;
@property (strong,nonatomic) NSString* nom;
@property (strong, nonatomic) NSString* prenom;
@property (strong, nonatomic) NSString* courriel;
-(NSString *) getToken;
-(void) test:(NSString *)token;
@end
