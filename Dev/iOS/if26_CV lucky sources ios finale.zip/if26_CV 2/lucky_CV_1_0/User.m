//
//  User.m
//  lucky_CV_1_0
//
//  Created by Igor VINCENT on 17/12/2013.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//

#import "User.h"

@implementation User
-(NSString *) getToken
{
    return _token;
}

-(void) test:(NSString *)token
{
    _token = token;
}
@end
