//
//  ListGameViewController.m
//  lucky_CV_1_0
//
//  Created by if26 on 03/12/13.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//

#import "ListGameViewController.h"

#import "GameViewController.h"
#import "WebServices.h"
#import "GameData.h"
#import "SBJson.h"
#define url_WebServQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)



@interface ListGameViewController ()

@end


@implementation ListGameViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
 
    }
    return self;
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.games = [[NSMutableArray alloc] init];
        self.gamesData = [[NSMutableArray alloc] init];
   
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

}

//appeler avant l'apparition de la vue

-(void) viewWillAppear:(BOOL)animated
{
    //[super viewWillAppear:<#animated#>];
    self.games = [[NSMutableArray alloc] init];
    [self.games removeAllObjects];
    [self.gamesData removeAllObjects];
    //création d'un objet webservice
    WebServices* webServ = [[WebServices alloc] init];
    //mise en place des valeurs posts de la requete
    NSString * token = [[NSString alloc] initWithFormat:@"data[Token]=%@",[[self getUser] getToken]];
    NSArray* postValues = [[NSArray alloc] initWithObjects:token, nil];
    
    //création de la chaine qui contiendra le json de retour
    NSString* valReturnHTTP = [[NSString alloc] init];
    //requete http (voir classwebserv)
    valReturnHTTP = [webServ requeteHttp:@"games" parametre:postValues];
    
    //parsage du jSon
    SBJsonParser *jsonParser = [SBJsonParser new];
    NSArray *jsonData = (NSArray*) [jsonParser objectWithString:valReturnHTTP error:nil];
 
    
    //parcours des données
    for(NSDictionary *dict in jsonData)
    {
        //verification du type
        if([dict isKindOfClass:[NSDictionary class]])
        {
            //parcours du dictionnaire (Game : array)
            for(NSString *key in dict)
            {
                //recuperation du sous dictionnaire
                NSDictionary *sousDict = [dict objectForKey:key];
                //vérification du type
                if([sousDict isKindOfClass:[NSDictionary class]])
                {
                    
                    //récuperation des valeurs du jeu courant
                    NSString * ident = [sousDict objectForKey:@"id"];
                    NSString * nom = [sousDict objectForKey:@"nom"];
                    NSString * style = [sousDict objectForKey:@"style"];
                    NSString * nbGagnant = [sousDict objectForKey:@"nbGagnant"];
                    NSString * probaVictoire = [sousDict objectForKey:@"proba"];
                    
                    //creation du jeu
                    GameData *gameData = [[GameData alloc] initWithName:nom style:style nbGagnant:nbGagnant identificateur:ident probaVictoire:probaVictoire];
                    //ajout au tableau de jeu
                    [self.gamesData addObject:gameData];
                    
                    
                }
                
            }
            
        }
    }
   
    for(GameData * temp in self.gamesData)
    {
        [self.games addObject:temp.nomJeu];
        
    }
    // set du background color
    self.view.backgroundColor=[UIColor whiteColor];
    //rechargement des données de la vue
    UITableView *view = (UITableView*)self.view;
    [view  reloadData];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return [self.games count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell
    cell.textLabel.text = [self.games objectAtIndex:indexPath.row];
    return cell;
}




// LISTENER SUR LA LISTE
#pragma mark - Table view delegate
// In a xib-based application, navigation from a table can be handled in -tableView:didSelectRowAtIndexPath:
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Récupèrer les champs de la liste qui sont cliqués par l'utilisateur
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    //index du tableau correspond à l'index du jeu dans le tableau de jeux
    //on instansie la vue et on récupere le gameData correspondant puis on push la view
    GameData *game = [_gamesData objectAtIndex:indexPath.row ];
    GameViewController *gameController = [[GameViewController alloc] initWithNibName:nil bundle:nil];
    [gameController setGameData:game];
    [gameController setUser:[self getUser]];
    [self.navigationController pushViewController:gameController animated:YES];
   
}
 
-(void) setUser:(User *)user_in
{
    _user = user_in;
}
-(User *) getUser
{
    return _user;
}



@end
