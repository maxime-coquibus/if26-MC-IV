//
//  GameData.m
//  lucky_CV_1_0
//
//  Created by Igor VINCENT on 02/01/2014.
//  Copyright (c) 2014 utt_CV. All rights reserved.
//

#import "GameData.h"

@implementation GameData

-(GameData *) initWithName:(NSString *)nom_ style:(NSString*)style_ nbGagnant:(NSString*)nbGagnant_ identificateur:(NSString*)identificateur_ probaVictoire:(NSString*)probaVictoire_
{
    //constructeur des données de jeu
    self.nomJeu = nom_;
    self.style = style_;
    self.nbGagnant = nbGagnant_;
    self.identificateur = identificateur_;
    self.probaVictoire = probaVictoire_;
    return self;
}
//getter

-(NSString *) getNom
{
    return self.nomJeu;
}

-(NSString *) getProbVictoire
{
    return self.probaVictoire;
}
-(NSString *) getId
{
    return self.identificateur;
}
-(NSString *) getStyle
{
    return self.style;
}
@end
