//
//  WebServices.h
//  lucky_CV_1_0
//
//  Created by Igor VINCENT on 17/12/2013.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//

#import <Foundation/Foundation.h>
#define url_WebServ [NSURL URLWithString:@"http://localhost/lucky/api/json"]

@interface WebServices : NSObject

-(NSString*) requeteHttp:(NSString*) urlJSON parametre:(NSArray*) params;

@end
