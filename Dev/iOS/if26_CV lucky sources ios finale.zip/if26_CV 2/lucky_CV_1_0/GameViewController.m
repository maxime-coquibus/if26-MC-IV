//
//  GameViewController.m
//  lucky_CV_1_0
//
//  Created by Igor VINCENT on 02/01/2014.
//  Copyright (c) 2014 utt_CV. All rights reserved.
//

#import "GameViewController.h"
#include <stdlib.h>
#import "WebServices.h"

@interface GameViewController ()

@end

@implementation GameViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    GameData * gameDataTest = self.gameData;
    
    NSString * nom = [gameDataTest getNom];
    _nomJeu.text = nom;
    //initialisation du style
    NSString * style = [gameDataTest getStyle];
    //style basique (et un peu moche)
    if([style isEqualToString:@"1"])
    {
        self.view.backgroundColor = [UIColor redColor];
    }else if([style isEqualToString:@"2"])
    {
        self.view.backgroundColor = [UIColor blueColor];
    }else if([style isEqualToString:@"3"])
    {
        self.view.backgroundColor = [UIColor greenColor];
    }
    

    // Do any additional setup after loading the view from its nib.
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
    // Dispose of any resources that can be recreated.
}



- (IBAction)jouer:(id)sender {
    //clic sur le bouton de jeu
    int chanceVict = [[self.gameData getProbVictoire] intValue];
    WebServices *ws = [[WebServices alloc] init];
    NSString * victoire;
    //url json
    int x = arc4random() % 100;
    if(x < chanceVict)
    {
        //victoire
        UIAlertView * alertVictoire = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Victoire",@"")message:NSLocalizedString(@"felicitation vous avez gagné", @"") delegate:nil cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil];
        [alertVictoire show];
        //envoie de requette de victoire
        victoire = @"data[Joue][victoire]=1";
        
    }else{
        //defaite
        UIAlertView * alertDefaite = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"défaite",@"")message:NSLocalizedString(@"Vous avez perdu, retentez votre chance demain", @"") delegate:nil cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil];
        [alertDefaite show];
        victoire  = @"data[Joue][victoire]=0";
    }
    [sender setEnabled:NO];
    // envoyer la requette de resultat

    NSString * token= [[NSString alloc] initWithFormat:@"data[Token]=%@",[_user getToken]];
    NSString * game_id=  [[NSString alloc] initWithFormat:@"data[Joue][game_id]=%@",[_gameData getId]];
    NSArray * postValues = [[NSArray alloc] initWithObjects:token,game_id,victoire, nil];
    [ws requeteHttp:@"setResult" parametre:postValues];
    // revenir au tabview 
}

@end
