<?php
class JsonController extends ApiAppController
{
	public function beforeFilter()
	{
		
		//si ce n'est pas une requete de login, verifier token
		/*if($this->request['param']['action'] != 'login')
		{
			//if($this->User->checkToken($this->request->data['token']))
			{

			}
		}*/

		 parent::beforeFilter();
        $this->Auth->allow('login');
      //  $this->request->data['User']['password'] = AuthComponent::password($this->request->data['User']['password']);
       $fic = fopen("log.txt","a+");
		ob_start();
		print_r($this->request);
		fwrite($fic,ob_get_contents());
		ob_clean();
		fclose($fic);

		//vérification du token
		if(isset($this->request->data['token']))
		{
			if($this->verifToken($this->request->data['token']))
			{

			}
		}
		
	}
	/*
		Fonction vérifiant 
	*/
	private function verifToken($token)
	{
		return true;
	}

	public function login()
	{
		//check
		//$this->request['data']['User']['username'] = $this->request['data']['username'];
		//$this->request['data']['User']['password'] = $this->request['data']['password'];
		//$post['username'] = $this->request->data['username'];
		//$post['password'] = $this->request->data['password'];
		$fic = fopen("log.txt","a+");
		ob_start();	
		print_r($this->request->data);
		fwrite($fic,ob_get_contents());
		ob_clean();
		fclose($fic);
		/*
		//set token
		$this->loadModel('Game');
		$lama = $this->Game->getGames();
		//$lama = array('lama'=>'koalas','lama2'=> 'koalas2');
		$lama = json_encode($lama);


		$this->set(array('jsonValue'=>$lama));
		*/
		//si les valeurs de session sont deja présente au lancement
		// p-e un bug mais si logguer avant possibilité de ce logguer avec n'importe quel valeur
		$this->Auth->logout();
		if($this->Auth->login())
		{
			//generate token

			// le token generer sera stocké avec l'id de l'user et une date de validité. 
			$this->layout = "ajax";
			$this->set(array("jsonValue" => json_encode(array("success"=>1,"token"=>"paslama"))));
		}else{
			$this->layout = "ajax";
			$this->set(array("jsonValue" => json_encode(array("success"=>0))));
		}
	}


	public function login2 () {
		if($this->request->is('post')) {
			$post['username'] = $this->request->data['username'];
			$post['password'] = $this->request->data['password'];
			//$post['android_registration_id'] = $this->request->data['reg_id'];
			$data['hash'] = $this->Auth->password($post['password']);
			$check = $this->User->find('first',
				array(
					'conditions' => array(
						'username' => $post['username'],
						'password' => $data['hash']
					)
				)
			);
			$save = array();
			$return = array();
			if($check) {
				$save['id'] = $check['User']['id'];
				$save['token'] = $this->Auth->password($post['username'].date('dmY'));
				$save['android_registration_id'] = $this->request->data['reg_id'];
				$save['last_mobile_login'] = date('Y-m-d H:i:s');
				if($this->User->save($save)) {
					$return['return']['token'] = $save['token'];
					$return['return']['hash'] = $data['hash'];
					$return['return']['id'] = $check['User']['id'];
					$return['return']['username'] = $check['User']['username'];
				} else {
					$return = false;
				}
			} else {
				$return = false;
			}
		}
		return new CakeResponse(array('body' => json_encode($return, JSON_NUMERIC_CHECK)));
	}

	public function games()
	{
		//layout vide permettant de renvoyer du json
		$this->layout = 'ajax';
		$this->set(array('json'=>json_encode(array('games'=>'games'))));
	}

}



?>