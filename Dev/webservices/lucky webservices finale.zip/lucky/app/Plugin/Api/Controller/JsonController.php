<?php
class JsonController extends ApiAppController
{
	//appelé avant chaque action
	public function beforeFilter()
	{

		 parent::beforeFilter();
		 //autorise l'accès à l'action login pour tout le monde
        $this->Auth->allow('login','addUser');


		//vérification du token
	
		
	}

	//action de login
	public function login()
	{
		//bannissement ici
		
		//si les valeurs de session sont deja présente au lancement
		// p-e un bug mais si logguer avant possibilité de ce logguer avec n'importe quel valeur
		$this->Auth->logout();
		if($this->Auth->login())
		{
			//generate token

			// le token generer sera stocké avec l'id de l'user et une date de validité. 
			$this->layout = "ajax";
			$this->set(array("jsonValue" => json_encode(array("success"=>1,"token"=>$this->createToken($this->Auth->User('id'))))));
		}else{
			$this->layout = "ajax";
			$this->set(array("jsonValue" => json_encode(array("success"=>0))));
		}
	}

	private function createToken($user_id)
	{
		$this->LoadModel('Token');
		//vérification d'un token existant
		$res = $this->Token->find('all',array('conditions'=>array('user_id'=>$user_id)));
		if(!empty($res))
		{
			if($this->checkToken($res[0]['Token']['value']))
			{
				return $res[0]['Token']['value'];
			}else{
				$this->Token->id = $res[0]['Token']['id'];
				$this->Token->delete();
			}
		}
		$this->Token->Create();
		$data = array();
		$data['Token']['user_id'] = $user_id;
		$data['Token']['value'] = md5($user_id);
		$this->Token->save($data);

		return $data['Token']['value'];
	}

	private function checkToken($token)
	{
		
		$this->LoadModel('Token');
		$res = $this->Token->find('all', array('conditions'=>array('value'=>$token)));
		//debug($res);exit();

		$created = $res[0]['Token']['created'];
		$date = date("Ymdhis");
		return true;
		//return strtotime($created) < strtotime($date)+(60*15);
		
	}
	public function games()
	{
		if($this->checkToken($this->request->data['Token']))
		{
			$this->LoadModel('Game');
			$this->LoadModel('Joue');
			
			$res = $this->Joue->getGamesForUser($this->getIdFromToken($this->request->data['Token'])['User']['id']);
			$gamesNotAvailable = array();
			foreach($res as $key =>$value)
			{
			    if(strtotime($value['Joue']['created'])+24*60*60 > strtotime(date('Ymdhis')))
			    {
			        array_push($gamesNotAvailable, $value['game']['id']);
			    }
			}
   			$games =$this->Game->find('all', array('conditions'=>array('NOT'=>array('id'=>array_values($gamesNotAvailable)))));
			$i = 0;

			foreach ($games as $key => $value) {
			foreach ($value as $key2 => $value2) {
					$res[$i] = $value2;
					$i++;
				}

			}
		}else{
			$games = array('erreur'=>'token');
		}
		
		//layout vide permettant de renvoyer du json
		$this->layout = 'ajax';
		$this->set(array('json'=>json_encode($games)));
	}
	//met à jour la base avec les resultats du jeu
	public function setResult()
	{
		if($this->checkToken($this->request->data['Token']))
		{
			$this->request->data['Joue']['user_id'] = $this->getIdFromToken($this->request->data['Token'])['User']['id'];
			$this->LoadModel('Joue');
			
			$this->Joue->User->id = $this->request->data['Joue']['user_id'];
			$this->Joue->Game->id = $this->request->data['Joue']['game_id'];
			$this->request->date['Joue']['dateJeu'] = date('Ymdhis');
			$res= $this->Joue->add($this->request->data);

		}else{
			$res = array('erreur'=>'token');
		}
		$this->layout = 'ajax';
		$this->set(array('res'=>json_encode($res)));
	}

	private function getIdFromToken($token)
	{
		$this->LoadModel('Token');
		return $this->Token->find('first', array('conditions'=>array('value'=>$token)));
	}
	public function addUser()
	{
		if($this->request->is('post'))
		{

        	$this->LoadModel('User');
        	$res = $this->User->find('all',array('conditions' => array('username'=>$this->request->data['User']['username'])));


        	if(empty($res))
        	{
        		$res = $this->User->find('all',array('conditions' => array('email'=>$this->request->data['User']['email'])));
        		if(empty($res))
        		{
        			$this->User->create();
        			$res =$this->User->save($this->request->data);
        			$this->set(array('res'=>json_encode(array('erreur'=>'0','success'=>'1'))));	
        		}else{
        			$this->set(array('res'=>json_encode(array('erreur'=>'erreur d\'inscription, email existant','success'=>'0'))));	
        		}
        		
        	}else{
        		$this->set(array('res'=>json_encode(array('erreur'=>'erreur d\'inscription, login existant','success'=>'0'))));
        	}
        	
		}else{
			$this->set(array('res'=>json_encode(array('erreur'=>'erreur d\'inscription','success'=>'0'))));
		}
		$this->layout = 'ajax';
		

	}

}



?>