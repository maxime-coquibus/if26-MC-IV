<?php
class Token extends AppModel
{
	public $belongsTo = array(
		'User' => array());
	

}

?>