<?php
class joue extends AppModel
{
	public $belongsTo = array(
		'User' => array(),
		'game' => array()
		);

	public function getGamesForUser($user_id)
	{
		return $this->find('all',array('conditions'=>array('user_id'=>$user_id)));
	}

	public function add($data)
	{
		$this->create();
		$this->save($data);
	}
}



?>