<?php
class Game extends AppModel
{
	public function getGames()
	{
		$query = $this->find('all');
		return $query;
	}


}


?>