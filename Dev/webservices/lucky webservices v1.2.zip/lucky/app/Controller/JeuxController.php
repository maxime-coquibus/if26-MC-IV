<?php
//chargement du composant Auth
App::uses('AuthComponent', 'Controller/Component');

class GamesController extends AppController {
	public $components = array(
    'Auth' => array(
        'loginAction' => array(
            'controller' => 'games',
            'action' => 'login'
        ),
        'authError' => 'Pensiez-vous réellement que vous étiez autorisés à voir cela ?',
        'authenticate' => array(
            'Form' => array(
                'fields' => array('username' => 'email')
            ),
            'Digest' => array()
        )
    )
);
	// fonction du coeur de cakePhp qui permet de configurer les composants (regroupement de code pour les controller)
	public function beforefilter()
	{
		// $this->Auth->authenticate = array(
  //   		AuthComponent::ALL => array('userModel' => 'Membre'),
  //   		'Digest',
  //   		'Form'
		// 	);
		// 'Auth' => array(
  //       'authenticate' => array(
  //           'Form' => array(
  //               'fields' => array('username' => 'email')
  //           )
  //       )
  //   )

	}

	public function login()
	{
		if($this->request->is('post'))
		{
			debug($this->request->data);
			$login = $this->data['login'];
			$password = $this->data['password'];
			if($this->Auth->login($this->request->data))
			{

			}

		}
	}




}

?>