<?php
//chargement du composant Auth
App::uses('AuthComponent', 'Controller/Component');

class GamesController extends AppController {

public function beforeFilter() {
    parent::beforeFilter();
}


  public function dashboard()
  {
    if($this->request->is('post'))
    {
        $this->Game->save($this->request->data);
    }
    $res = $this->Game->getGames();
    $this->set(array('games'=>$res));
  }

 
  public function delete($id)
  {
    $this->Game->id = $id;
    $this->Game->delete();
    $this->redirect('/games/dashboard/');
  }


}

?>