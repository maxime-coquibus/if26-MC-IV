<?php
class JsonController extends ApiAppController
{
	//appelé avant chaque action
	public function beforeFilter()
	{

		 parent::beforeFilter();
		 //autorise l'accès à l'action login pour tout le monde
        $this->Auth->allow('login');


      //  $this->request->data['User']['password'] = AuthComponent::password($this->request->data['User']['password']);
      /* $fic = fopen("log.txt","a+");
		ob_start();
		print_r($this->request);
		fwrite($fic,ob_get_contents());
		ob_clean();
		fclose($fic);*/

		//vérification du token
		if(isset($this->request->data['token']))
		{
			if($this->verifToken($this->request->data['token']))
			{
				
			}
		}
		
	}
	/*
		Fonction vérifiant 
	*/
	private function verifToken($token)
	{
		return true;
	}

	/*private function createToken()
	{

		$fic = fopen("log.txt","a+");
		ob_start();	
		print_r();
		fwrite($fic,ob_get_contents());
		ob_clean();
		fclose($fic);
		$user_id = $this->Auth->user('id');
		
		return "token";
	}*/

	public function login()
	{
		//bannissement ici
		
		//si les valeurs de session sont deja présente au lancement
		// p-e un bug mais si logguer avant possibilité de ce logguer avec n'importe quel valeur
		$this->Auth->logout();
		if($this->Auth->login())
		{
			//generate token

			// le token generer sera stocké avec l'id de l'user et une date de validité. 
			$this->layout = "ajax";
			$this->set(array("jsonValue" => json_encode(array("success"=>1,"token"=>"token"))));
		}else{
			$this->layout = "ajax";
			$this->set(array("jsonValue" => json_encode(array("success"=>0))));
		}
	}

	public function games()
	{
		$fic = fopen("log.txt","a+");
		ob_start();	
		print_r($this->request->data);
		fwrite($fic,ob_get_contents());
		ob_clean();
		fclose($fic);

		$this->LoadModel('Game');
		$games = $this->Game->getGames();
		//layout vide permettant de renvoyer du json
		$this->layout = 'ajax';
		$this->set(array('json'=>json_encode($games)));
	}

}



?>