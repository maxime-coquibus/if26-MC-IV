//
//  InscriptionViewController.h
//  lucky_CV_1_0
//
//  Created by if26 on 12/12/13.
//  Copyright (c) 2013 utt_CV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InscriptionViewController : UIViewController

@end
